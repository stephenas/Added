
import Foundation
//import Glibc

// you can write to stdout for debugging purposes, e.g.
// print("this is a debug message")

var input = [1,2,3,1,2,3,4,4]

print(input)

public func solution(_ A : inout [Int]) -> Int {
    // write your code in Swift 3.0 (Linux)
    var newDict = [Int: Int]()
    
    for element in A {
        if let count = newDict[element] {
            newDict[element] = count + 1
        } else {
            newDict[element] = 1
        }
    }
    let res = newDict.filter{$0.value == 1}
    return res.keys.first!
}


print(solution(&input))
